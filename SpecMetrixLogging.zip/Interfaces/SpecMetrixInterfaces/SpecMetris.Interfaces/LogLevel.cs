﻿namespace SpecMetrix.Interfaces;

public enum LogLevel
{
    Debug,
    Info,
    Warn,
    Error,
    Fatal,
}
