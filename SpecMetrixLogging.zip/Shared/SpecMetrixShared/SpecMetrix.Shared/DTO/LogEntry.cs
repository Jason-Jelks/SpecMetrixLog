﻿namespace SpecMetrix.Shared.DTO;

/// <summary>
/// Logging
/// </summary>
public class LogEntry
{
}
